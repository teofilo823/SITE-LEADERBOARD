const fs = require('fs');
const { EmbedBuilder } = require('discord.js');
const BANS_PATH = './bans.json';

function loadBans() {
    if (!fs.existsSync(BANS_PATH)) fs.writeFileSync(BANS_PATH, JSON.stringify({}));
    return JSON.parse(fs.readFileSync(BANS_PATH));
}

function saveBans(data) {
    fs.writeFileSync(BANS_PATH, JSON.stringify(data, null, 4));
}

async function executarBan(interaction) {
    const listBans = loadBans();
    const target = interaction.options.getUser('jogador');
    const motivo = interaction.options.getString('motivo');

    listBans[target.id] = { 
        motivo: motivo, 
        data: new Date().toLocaleDateString('pt-BR') 
    };

    saveBans(listBans);

    const embed = new EmbedBuilder()
        .setTitle("🚫 JOGADOR BANIDO")
        .setDescription(`${target} foi banido das partidas ranqueadas.`)
        .addFields(
            { name: "📝 Motivo", value: motivo },
            { name: "📅 Data", value: listBans[target.id].data }
        )
        .setColor("#FF0000")
        .setThumbnail(target.displayAvatarURL());

    await interaction.reply({ embeds: [embed] });
}

// NOVA FUNÇÃO: UNBAN
async function executarUnban(interaction) {
    const listBans = loadBans();
    const target = interaction.options.getUser('jogador');

    if (!listBans[target.id]) {
        return interaction.reply({ content: `❌ O jogador ${target} não está na lista de punidos.`, flags: [64] });
    }

    delete listBans[target.id];
    saveBans(listBans);

    const embed = new EmbedBuilder()
        .setTitle("✅ PUNIÇÃO REMOVIDA")
        .setDescription(`${target} foi desbanido e já pode participar das ranqueadas novamente.`)
        .setColor("#00FF00")
        .setTimestamp();

    await interaction.reply({ embeds: [embed] });
}

async function listarPunidos(interaction) {
    const bans = loadBans();
    const ids = Object.keys(bans);

    if (ids.length === 0) {
        return interaction.reply({ content: "✅ Não há nenhum jogador na lista de punidos no momento.", flags: [64] });
    }

    const listaFormatada = ids.map(id => `• <@${id}> | Motivo: \`${bans[id].motivo}\` (${bans[id].data})`).join('\n');

    const embed = new EmbedBuilder()
        .setTitle("🚫 LISTA DE JOGADORES PUNIDOS")
        .setDescription(listaFormatada)
        .setColor("#2B2D31")
        .setTimestamp();

    await interaction.reply({ embeds: [embed], flags: [64] });
}

module.exports = { 
    executarBan, 
    executarUnban, // Exportado
    loadBans, 
    listarPunidos 
};